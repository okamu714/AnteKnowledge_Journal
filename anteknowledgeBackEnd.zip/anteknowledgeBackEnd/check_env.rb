require 'dotenv/load'

puts ENV['RDS_USERNAME']
puts ENV['RDS_PASSWORD']
puts ENV['RDS_HOSTNAME']
puts ENV['RDS_DATABASE']
