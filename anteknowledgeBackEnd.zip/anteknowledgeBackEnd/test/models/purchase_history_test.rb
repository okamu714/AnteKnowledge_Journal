require "test_helper"

class PurchaseHistoryTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
