# require 'stripe'

Stripe.api_key = ENV['STRIPE_SECRET_KEY'] || 'sk_test_51QMsOaK9yUy0vysUgK4ooBwpB3D0dv57DOiOJgGiGHgmZsVQqzBnkjyiwMbU3t5CN47idgAxwLrBuv6tSmIhCvaj00c9G3y1yR'

